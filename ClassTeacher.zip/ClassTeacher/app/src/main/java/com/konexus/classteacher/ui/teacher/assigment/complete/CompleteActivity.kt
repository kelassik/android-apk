package com.konexus.classteacher.ui.teacher.assigment.complete

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.konexus.classteacher.R

class CompleteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_complete)
    }
}