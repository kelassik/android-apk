package com.konexus.classteacher.model

open class Sekolah(
    open var imgSekolah: Int = 0,
    open var namaSekolah: String = ""
)