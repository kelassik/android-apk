package com.konexus.classteacher.model

class Absent(
    var nomer: String ="",
    var name: String = "",
    var image: Int = 0
)