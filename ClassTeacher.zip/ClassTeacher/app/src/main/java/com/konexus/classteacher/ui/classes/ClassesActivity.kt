package com.konexus.classteacher.ui.classes

import androidx.appcompat.app.AppCompatActivity

class ClassesActivity : AppCompatActivity() {


}