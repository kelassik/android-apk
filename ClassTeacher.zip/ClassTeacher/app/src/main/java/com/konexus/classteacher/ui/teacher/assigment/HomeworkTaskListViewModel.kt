package com.konexus.classteacher.ui.teacher.assigment

import com.konexus.classteacher.BaseViewModel

class HomeworkTaskListViewModel : BaseViewModel() {

    companion object{

        const val BACK_ONCLICK_HOMEWORKTASKLIST = "back_onclick_homeworktasklist"
        const val ONGOING_TASK_ONCLICK = "ongoing_task_onclick"
        const val INPROGRESS_TASK_ONCLICK = "inprogress_task_onclick"
        const val COMPLETE_TASK_ONCLICK = "complete_task_onclick"
        const val UPLOAD_TASK_ONCLICK = "upload_task_onclick"
    }

    fun backOnclickHomeworkTaskList(){
        action.value = BACK_ONCLICK_HOMEWORKTASKLIST
    }
    fun ongoingTaskOnclick(){
        action.value = ONGOING_TASK_ONCLICK
    }
    fun inprogressTaskOnclick(){
        action.value = INPROGRESS_TASK_ONCLICK
    }
    fun completeTaskOnclick(){
        action.value = COMPLETE_TASK_ONCLICK
    }
    fun uploadTaskOnclick(){
        action.value = UPLOAD_TASK_ONCLICK
    }
}