package com.konexus.classteacher.model

class Hari(
    var hari: String = "",
    var schedule: ArrayList<Schedule> = arrayListOf()
)