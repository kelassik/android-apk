package com.konexus.classteacher.utill

object Utill {

}