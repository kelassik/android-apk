package com.konexus.classteacher.model

import android.graphics.Bitmap

class Discussion(
    var judul: String = "",
    var timepos: String = "",
    var posting: String = "",
    var postGambar: Bitmap? = null
)