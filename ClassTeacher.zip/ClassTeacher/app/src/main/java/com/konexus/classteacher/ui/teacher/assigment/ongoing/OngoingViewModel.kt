package com.konexus.classteacher.ui.teacher.assigment.ongoing

import com.konexus.classteacher.BaseViewModel

class OngoingViewModel : BaseViewModel() {

    companion object{

        const val ACTION_BACK_ONCLICK = "action_back_onclick"
    }

    fun backOnclick(){
        action.value = ACTION_BACK_ONCLICK
    }
}