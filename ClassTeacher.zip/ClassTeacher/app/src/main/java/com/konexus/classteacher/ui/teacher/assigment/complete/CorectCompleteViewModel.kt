package com.konexus.classteacher.ui.teacher.assigment.complete

class CorectCompleteViewModel {
}