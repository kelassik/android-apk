package com.konexus.classteacher.ui.teacher.assigment.ongoing

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.konexus.classteacher.R

class OnGoingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_on_going)
    }
}